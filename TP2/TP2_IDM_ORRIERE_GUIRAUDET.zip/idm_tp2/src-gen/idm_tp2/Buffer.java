/**
 */
package idm_tp2;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Buffer</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link idm_tp2.Buffer#getInitialValue <em>Initial Value</em>}</li>
 *   <li>{@link idm_tp2.Buffer#getName <em>Name</em>}</li>
 *   <li>{@link idm_tp2.Buffer#getIncomingFsm <em>Incoming Fsm</em>}</li>
 *   <li>{@link idm_tp2.Buffer#getOutgoingfsm <em>Outgoingfsm</em>}</li>
 * </ul>
 *
 * @see idm_tp2.Idm_tp2Package#getBuffer()
 * @model
 * @generated
 */
public interface Buffer extends EObject {
	/**
	 * Returns the value of the '<em><b>Initial Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Initial Value</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Initial Value</em>' attribute.
	 * @see #setInitialValue(String)
	 * @see idm_tp2.Idm_tp2Package#getBuffer_InitialValue()
	 * @model
	 * @generated
	 */
	String getInitialValue();

	/**
	 * Sets the value of the '{@link idm_tp2.Buffer#getInitialValue <em>Initial Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Initial Value</em>' attribute.
	 * @see #getInitialValue()
	 * @generated
	 */
	void setInitialValue(String value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see idm_tp2.Idm_tp2Package#getBuffer_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link idm_tp2.Buffer#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Incoming Fsm</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link idm_tp2.FSM#getOutputBuffer <em>Output Buffer</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Incoming Fsm</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Incoming Fsm</em>' reference.
	 * @see #setIncomingFsm(FSM)
	 * @see idm_tp2.Idm_tp2Package#getBuffer_IncomingFsm()
	 * @see idm_tp2.FSM#getOutputBuffer
	 * @model opposite="outputBuffer"
	 * @generated
	 */
	FSM getIncomingFsm();

	/**
	 * Sets the value of the '{@link idm_tp2.Buffer#getIncomingFsm <em>Incoming Fsm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Incoming Fsm</em>' reference.
	 * @see #getIncomingFsm()
	 * @generated
	 */
	void setIncomingFsm(FSM value);

	/**
	 * Returns the value of the '<em><b>Outgoingfsm</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link idm_tp2.FSM#getInputBuffer <em>Input Buffer</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Outgoingfsm</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Outgoingfsm</em>' reference.
	 * @see #setOutgoingfsm(FSM)
	 * @see idm_tp2.Idm_tp2Package#getBuffer_Outgoingfsm()
	 * @see idm_tp2.FSM#getInputBuffer
	 * @model opposite="inputBuffer"
	 * @generated
	 */
	FSM getOutgoingfsm();

	/**
	 * Sets the value of the '{@link idm_tp2.Buffer#getOutgoingfsm <em>Outgoingfsm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Outgoingfsm</em>' reference.
	 * @see #getOutgoingfsm()
	 * @generated
	 */
	void setOutgoingfsm(FSM value);


} // Buffer

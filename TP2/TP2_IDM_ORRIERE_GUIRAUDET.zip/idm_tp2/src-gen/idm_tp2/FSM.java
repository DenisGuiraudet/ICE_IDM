/**
 */
package idm_tp2;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>FSM</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link idm_tp2.FSM#getInitialState <em>Initial State</em>}</li>
 *   <li>{@link idm_tp2.FSM#getName <em>Name</em>}</li>
 *   <li>{@link idm_tp2.FSM#getOwnedState <em>Owned State</em>}</li>
 *   <li>{@link idm_tp2.FSM#getOwnedTransition <em>Owned Transition</em>}</li>
 *   <li>{@link idm_tp2.FSM#getOutputBuffer <em>Output Buffer</em>}</li>
 *   <li>{@link idm_tp2.FSM#getInputBuffer <em>Input Buffer</em>}</li>
 * </ul>
 *
 * @see idm_tp2.Idm_tp2Package#getFSM()
 * @model
 * @generated
 */
public interface FSM extends EObject {
	/**
	 * Returns the value of the '<em><b>Initial State</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Initial State</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Initial State</em>' reference.
	 * @see #setInitialState(State)
	 * @see idm_tp2.Idm_tp2Package#getFSM_InitialState()
	 * @model
	 * @generated
	 */
	State getInitialState();

	/**
	 * Sets the value of the '{@link idm_tp2.FSM#getInitialState <em>Initial State</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Initial State</em>' reference.
	 * @see #getInitialState()
	 * @generated
	 */
	void setInitialState(State value);

	/**
	 * Returns the value of the '<em><b>Owned State</b></em>' containment reference list.
	 * The list contents are of type {@link idm_tp2.State}.
	 * It is bidirectional and its opposite is '{@link idm_tp2.State#getFsm <em>Fsm</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Owned State</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Owned State</em>' containment reference list.
	 * @see idm_tp2.Idm_tp2Package#getFSM_OwnedState()
	 * @see idm_tp2.State#getFsm
	 * @model opposite="fsm" containment="true"
	 * @generated
	 */
	EList<State> getOwnedState();

	/**
	 * Returns the value of the '<em><b>Owned Transition</b></em>' containment reference list.
	 * The list contents are of type {@link idm_tp2.Transition}.
	 * It is bidirectional and its opposite is '{@link idm_tp2.Transition#getFsm <em>Fsm</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Owned Transition</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Owned Transition</em>' containment reference list.
	 * @see idm_tp2.Idm_tp2Package#getFSM_OwnedTransition()
	 * @see idm_tp2.Transition#getFsm
	 * @model opposite="fsm" containment="true"
	 * @generated
	 */
	EList<Transition> getOwnedTransition();

	/**
	 * Returns the value of the '<em><b>Output Buffer</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link idm_tp2.Buffer#getIncomingFsm <em>Incoming Fsm</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Output Buffer</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Output Buffer</em>' reference.
	 * @see #setOutputBuffer(Buffer)
	 * @see idm_tp2.Idm_tp2Package#getFSM_OutputBuffer()
	 * @see idm_tp2.Buffer#getIncomingFsm
	 * @model opposite="incomingFsm"
	 * @generated
	 */
	Buffer getOutputBuffer();

	/**
	 * Sets the value of the '{@link idm_tp2.FSM#getOutputBuffer <em>Output Buffer</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Output Buffer</em>' reference.
	 * @see #getOutputBuffer()
	 * @generated
	 */
	void setOutputBuffer(Buffer value);

	/**
	 * Returns the value of the '<em><b>Input Buffer</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link idm_tp2.Buffer#getOutgoingfsm <em>Outgoingfsm</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Input Buffer</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Input Buffer</em>' reference.
	 * @see #setInputBuffer(Buffer)
	 * @see idm_tp2.Idm_tp2Package#getFSM_InputBuffer()
	 * @see idm_tp2.Buffer#getOutgoingfsm
	 * @model opposite="outgoingfsm"
	 * @generated
	 */
	Buffer getInputBuffer();

	/**
	 * Sets the value of the '{@link idm_tp2.FSM#getInputBuffer <em>Input Buffer</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Input Buffer</em>' reference.
	 * @see #getInputBuffer()
	 * @generated
	 */
	void setInputBuffer(Buffer value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see idm_tp2.Idm_tp2Package#getFSM_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link idm_tp2.FSM#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);


} // FSM

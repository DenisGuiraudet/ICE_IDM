/**
 */
package idm_tp2.impl;

import idm_tp2.Buffer;
import idm_tp2.FSM;
import idm_tp2.Idm_tp2Package;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Buffer</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link idm_tp2.impl.BufferImpl#getInitialValue <em>Initial Value</em>}</li>
 *   <li>{@link idm_tp2.impl.BufferImpl#getName <em>Name</em>}</li>
 *   <li>{@link idm_tp2.impl.BufferImpl#getIncomingFsm <em>Incoming Fsm</em>}</li>
 *   <li>{@link idm_tp2.impl.BufferImpl#getOutgoingfsm <em>Outgoingfsm</em>}</li>
 * </ul>
 *
 * @generated
 */
public class BufferImpl extends MinimalEObjectImpl.Container implements Buffer {
	/**
	 * The default value of the '{@link #getInitialValue() <em>Initial Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInitialValue()
	 * @generated
	 * @ordered
	 */
	protected static final String INITIAL_VALUE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getInitialValue() <em>Initial Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInitialValue()
	 * @generated
	 * @ordered
	 */
	protected String initialValue = INITIAL_VALUE_EDEFAULT;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getIncomingFsm() <em>Incoming Fsm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIncomingFsm()
	 * @generated
	 * @ordered
	 */
	protected FSM incomingFsm;

	/**
	 * The cached value of the '{@link #getOutgoingfsm() <em>Outgoingfsm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutgoingfsm()
	 * @generated
	 * @ordered
	 */
	protected FSM outgoingfsm;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BufferImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Idm_tp2Package.Literals.BUFFER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getInitialValue() {
		return initialValue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setInitialValue(String newInitialValue) {
		String oldInitialValue = initialValue;
		initialValue = newInitialValue;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Idm_tp2Package.BUFFER__INITIAL_VALUE, oldInitialValue,
					initialValue));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Idm_tp2Package.BUFFER__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FSM getIncomingFsm() {
		if (incomingFsm != null && incomingFsm.eIsProxy()) {
			InternalEObject oldIncomingFsm = (InternalEObject) incomingFsm;
			incomingFsm = (FSM) eResolveProxy(oldIncomingFsm);
			if (incomingFsm != oldIncomingFsm) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Idm_tp2Package.BUFFER__INCOMING_FSM,
							oldIncomingFsm, incomingFsm));
			}
		}
		return incomingFsm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FSM basicGetIncomingFsm() {
		return incomingFsm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetIncomingFsm(FSM newIncomingFsm, NotificationChain msgs) {
		FSM oldIncomingFsm = incomingFsm;
		incomingFsm = newIncomingFsm;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Idm_tp2Package.BUFFER__INCOMING_FSM, oldIncomingFsm, newIncomingFsm);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIncomingFsm(FSM newIncomingFsm) {
		if (newIncomingFsm != incomingFsm) {
			NotificationChain msgs = null;
			if (incomingFsm != null)
				msgs = ((InternalEObject) incomingFsm).eInverseRemove(this, Idm_tp2Package.FSM__OUTPUT_BUFFER,
						FSM.class, msgs);
			if (newIncomingFsm != null)
				msgs = ((InternalEObject) newIncomingFsm).eInverseAdd(this, Idm_tp2Package.FSM__OUTPUT_BUFFER,
						FSM.class, msgs);
			msgs = basicSetIncomingFsm(newIncomingFsm, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Idm_tp2Package.BUFFER__INCOMING_FSM, newIncomingFsm,
					newIncomingFsm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FSM getOutgoingfsm() {
		if (outgoingfsm != null && outgoingfsm.eIsProxy()) {
			InternalEObject oldOutgoingfsm = (InternalEObject) outgoingfsm;
			outgoingfsm = (FSM) eResolveProxy(oldOutgoingfsm);
			if (outgoingfsm != oldOutgoingfsm) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Idm_tp2Package.BUFFER__OUTGOINGFSM,
							oldOutgoingfsm, outgoingfsm));
			}
		}
		return outgoingfsm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FSM basicGetOutgoingfsm() {
		return outgoingfsm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetOutgoingfsm(FSM newOutgoingfsm, NotificationChain msgs) {
		FSM oldOutgoingfsm = outgoingfsm;
		outgoingfsm = newOutgoingfsm;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Idm_tp2Package.BUFFER__OUTGOINGFSM, oldOutgoingfsm, newOutgoingfsm);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOutgoingfsm(FSM newOutgoingfsm) {
		if (newOutgoingfsm != outgoingfsm) {
			NotificationChain msgs = null;
			if (outgoingfsm != null)
				msgs = ((InternalEObject) outgoingfsm).eInverseRemove(this, Idm_tp2Package.FSM__INPUT_BUFFER, FSM.class,
						msgs);
			if (newOutgoingfsm != null)
				msgs = ((InternalEObject) newOutgoingfsm).eInverseAdd(this, Idm_tp2Package.FSM__INPUT_BUFFER, FSM.class,
						msgs);
			msgs = basicSetOutgoingfsm(newOutgoingfsm, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Idm_tp2Package.BUFFER__OUTGOINGFSM, newOutgoingfsm,
					newOutgoingfsm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Idm_tp2Package.BUFFER__INCOMING_FSM:
			if (incomingFsm != null)
				msgs = ((InternalEObject) incomingFsm).eInverseRemove(this, Idm_tp2Package.FSM__OUTPUT_BUFFER,
						FSM.class, msgs);
			return basicSetIncomingFsm((FSM) otherEnd, msgs);
		case Idm_tp2Package.BUFFER__OUTGOINGFSM:
			if (outgoingfsm != null)
				msgs = ((InternalEObject) outgoingfsm).eInverseRemove(this, Idm_tp2Package.FSM__INPUT_BUFFER, FSM.class,
						msgs);
			return basicSetOutgoingfsm((FSM) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Idm_tp2Package.BUFFER__INCOMING_FSM:
			return basicSetIncomingFsm(null, msgs);
		case Idm_tp2Package.BUFFER__OUTGOINGFSM:
			return basicSetOutgoingfsm(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Idm_tp2Package.BUFFER__INITIAL_VALUE:
			return getInitialValue();
		case Idm_tp2Package.BUFFER__NAME:
			return getName();
		case Idm_tp2Package.BUFFER__INCOMING_FSM:
			if (resolve)
				return getIncomingFsm();
			return basicGetIncomingFsm();
		case Idm_tp2Package.BUFFER__OUTGOINGFSM:
			if (resolve)
				return getOutgoingfsm();
			return basicGetOutgoingfsm();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Idm_tp2Package.BUFFER__INITIAL_VALUE:
			setInitialValue((String) newValue);
			return;
		case Idm_tp2Package.BUFFER__NAME:
			setName((String) newValue);
			return;
		case Idm_tp2Package.BUFFER__INCOMING_FSM:
			setIncomingFsm((FSM) newValue);
			return;
		case Idm_tp2Package.BUFFER__OUTGOINGFSM:
			setOutgoingfsm((FSM) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Idm_tp2Package.BUFFER__INITIAL_VALUE:
			setInitialValue(INITIAL_VALUE_EDEFAULT);
			return;
		case Idm_tp2Package.BUFFER__NAME:
			setName(NAME_EDEFAULT);
			return;
		case Idm_tp2Package.BUFFER__INCOMING_FSM:
			setIncomingFsm((FSM) null);
			return;
		case Idm_tp2Package.BUFFER__OUTGOINGFSM:
			setOutgoingfsm((FSM) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Idm_tp2Package.BUFFER__INITIAL_VALUE:
			return INITIAL_VALUE_EDEFAULT == null ? initialValue != null : !INITIAL_VALUE_EDEFAULT.equals(initialValue);
		case Idm_tp2Package.BUFFER__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case Idm_tp2Package.BUFFER__INCOMING_FSM:
			return incomingFsm != null;
		case Idm_tp2Package.BUFFER__OUTGOINGFSM:
			return outgoingfsm != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (initialValue: ");
		result.append(initialValue);
		result.append(", name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //BufferImpl

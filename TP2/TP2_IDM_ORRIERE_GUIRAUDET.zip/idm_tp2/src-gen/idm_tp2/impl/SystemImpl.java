/**
 */
package idm_tp2.impl;

import idm_tp2.Buffer;
import idm_tp2.FSM;
import idm_tp2.Idm_tp2Package;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>System</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link idm_tp2.impl.SystemImpl#getOwnedBuffer <em>Owned Buffer</em>}</li>
 *   <li>{@link idm_tp2.impl.SystemImpl#getOwnedFsm <em>Owned Fsm</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SystemImpl extends MinimalEObjectImpl.Container implements idm_tp2.System {
	/**
	 * The cached value of the '{@link #getOwnedBuffer() <em>Owned Buffer</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOwnedBuffer()
	 * @generated
	 * @ordered
	 */
	protected EList<Buffer> ownedBuffer;

	/**
	 * The cached value of the '{@link #getOwnedFsm() <em>Owned Fsm</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOwnedFsm()
	 * @generated
	 * @ordered
	 */
	protected EList<FSM> ownedFsm;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SystemImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Idm_tp2Package.Literals.SYSTEM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Buffer> getOwnedBuffer() {
		if (ownedBuffer == null) {
			ownedBuffer = new EObjectContainmentEList<Buffer>(Buffer.class, this, Idm_tp2Package.SYSTEM__OWNED_BUFFER);
		}
		return ownedBuffer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<FSM> getOwnedFsm() {
		if (ownedFsm == null) {
			ownedFsm = new EObjectContainmentEList<FSM>(FSM.class, this, Idm_tp2Package.SYSTEM__OWNED_FSM);
		}
		return ownedFsm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Idm_tp2Package.SYSTEM__OWNED_BUFFER:
			return ((InternalEList<?>) getOwnedBuffer()).basicRemove(otherEnd, msgs);
		case Idm_tp2Package.SYSTEM__OWNED_FSM:
			return ((InternalEList<?>) getOwnedFsm()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Idm_tp2Package.SYSTEM__OWNED_BUFFER:
			return getOwnedBuffer();
		case Idm_tp2Package.SYSTEM__OWNED_FSM:
			return getOwnedFsm();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Idm_tp2Package.SYSTEM__OWNED_BUFFER:
			getOwnedBuffer().clear();
			getOwnedBuffer().addAll((Collection<? extends Buffer>) newValue);
			return;
		case Idm_tp2Package.SYSTEM__OWNED_FSM:
			getOwnedFsm().clear();
			getOwnedFsm().addAll((Collection<? extends FSM>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Idm_tp2Package.SYSTEM__OWNED_BUFFER:
			getOwnedBuffer().clear();
			return;
		case Idm_tp2Package.SYSTEM__OWNED_FSM:
			getOwnedFsm().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Idm_tp2Package.SYSTEM__OWNED_BUFFER:
			return ownedBuffer != null && !ownedBuffer.isEmpty();
		case Idm_tp2Package.SYSTEM__OWNED_FSM:
			return ownedFsm != null && !ownedFsm.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //SystemImpl

/**
 */
package idm_tp2.impl;

import idm_tp2.Buffer;
import idm_tp2.FSM;
import idm_tp2.Idm_tp2Factory;
import idm_tp2.Idm_tp2Package;
import idm_tp2.State;
import idm_tp2.Transition;
import idm_tp2.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Idm_tp2FactoryImpl extends EFactoryImpl implements Idm_tp2Factory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Idm_tp2Factory init() {
		try {
			Idm_tp2Factory theIdm_tp2Factory = (Idm_tp2Factory) EPackage.Registry.INSTANCE
					.getEFactory(Idm_tp2Package.eNS_URI);
			if (theIdm_tp2Factory != null) {
				return theIdm_tp2Factory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new Idm_tp2FactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Idm_tp2FactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case Idm_tp2Package.FSM:
			return createFSM();
		case Idm_tp2Package.STATE:
			return createState();
		case Idm_tp2Package.TRANSITION:
			return createTransition();
		case Idm_tp2Package.BUFFER:
			return createBuffer();
		case Idm_tp2Package.SYSTEM:
			return createSystem();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FSM createFSM() {
		FSMImpl fsm = new FSMImpl();
		return fsm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public State createState() {
		StateImpl state = new StateImpl();
		return state;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Transition createTransition() {
		TransitionImpl transition = new TransitionImpl();
		return transition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Buffer createBuffer() {
		BufferImpl buffer = new BufferImpl();
		return buffer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public idm_tp2.System createSystem() {
		SystemImpl system = new SystemImpl();
		return system;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Idm_tp2Package getIdm_tp2Package() {
		return (Idm_tp2Package) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static Idm_tp2Package getPackage() {
		return Idm_tp2Package.eINSTANCE;
	}

} //Idm_tp2FactoryImpl

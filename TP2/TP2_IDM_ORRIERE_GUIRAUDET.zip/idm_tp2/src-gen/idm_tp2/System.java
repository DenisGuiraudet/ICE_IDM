/**
 */
package idm_tp2;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>System</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link idm_tp2.System#getOwnedBuffer <em>Owned Buffer</em>}</li>
 *   <li>{@link idm_tp2.System#getOwnedFsm <em>Owned Fsm</em>}</li>
 * </ul>
 *
 * @see idm_tp2.Idm_tp2Package#getSystem()
 * @model
 * @generated
 */
public interface System extends EObject {
	/**
	 * Returns the value of the '<em><b>Owned Buffer</b></em>' containment reference list.
	 * The list contents are of type {@link idm_tp2.Buffer}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Owned Buffer</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Owned Buffer</em>' containment reference list.
	 * @see idm_tp2.Idm_tp2Package#getSystem_OwnedBuffer()
	 * @model containment="true"
	 * @generated
	 */
	EList<Buffer> getOwnedBuffer();

	/**
	 * Returns the value of the '<em><b>Owned Fsm</b></em>' containment reference list.
	 * The list contents are of type {@link idm_tp2.FSM}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Owned Fsm</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Owned Fsm</em>' containment reference list.
	 * @see idm_tp2.Idm_tp2Package#getSystem_OwnedFsm()
	 * @model containment="true"
	 * @generated
	 */
	EList<FSM> getOwnedFsm();

} // System
